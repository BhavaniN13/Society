const db = require("../db/connection");
const jwt = require("jsonwebtoken");

module.exports = (function () {
  return {
    signup: (req, res) => {
      const {
        Firstname,
        Lastname,
        Emailid,
        Password,
        Address,
        Phonenumber,
        RoleId,
        FlatNo,
      } = req.body;

      db.query(
        "SELECT * FROM users WHERE Emailid = ?",
        Emailid,
        async (error, results) => {
          if (error) {
            console.error("Error checking email ID:", error);
            return res.status(500).json({ error: "Internal server error" });
          }

          if (results.length > 0) {
            // Email ID already exists
            return res.status(400).json({
              error: "Email ID already registered Try with Another",
            });
          }
        }
      );
      const newUser = {
        Firstname,
        Lastname,
        Emailid,
        Password,
        Address,
        Phonenumber,
        RoleId,
        CreatedAt: new Date(),
        FlatNo,
      };

      const sql = "INSERT INTO users SET ?";

      db.query(sql, newUser, (err, result) => {
        if (err) {
          console.log(err);
          res.status(500).send("Error saving data");
          return;
        }
        console.log("User registered:", result);
        res.status(200).send("User registered successfully");
      });
    },
    getuser: (req, res) => {
      const page = parseInt(req.query.page) || 1; // Current page, default is 1
      const perPage = parseInt(req.query.perPage) || 10; // Number of items per page, default is 10

      // Calculate the offset based on the current page and items per page
      const offset = (page - 1) * perPage;

      // Query to fetch users with pagination
      const sql = `SELECT * FROM users LIMIT ${perPage} OFFSET ${offset}`;

      // Query to count total users
      const countQuery = "SELECT COUNT(*) AS total FROM users";

      db.query(countQuery, (countErr, countResult) => {
        if (countErr) {
          console.error("Error counting users:", countErr);
          res.status(500).json({ error: "Error counting users" });
          return;
        }

        const total = countResult[0].total;

        // Execute main query to fetch users
        db.query(sql, (err, result) => {
          if (err) {
            console.error("Error fetching users:", err);
            res.status(500).json({ error: "Error fetching users" });
            return;
          }

          // Calculate total pages
          const totalPages = Math.ceil(total / perPage);
          console.log(totalPages);

          // Send retrieved records along with pagination metadata as response
          res.json({
            page,
            perPage,
            total,
            totalPages,
            users: result,
          });
        });
      });

      // db.query("SELECT * FROM users", (err, result) => {
      //   if (err) throw err;

      //   // Send retrieved records as response
      //   res.json(result);
      // });
    },
    updateuser: (req, res) => {
      const userId = req.body.userId;
      const updatedData = req.body; // Assuming the request body contains the updated data

      // Query database to update record
      db.query(
        "UPDATE users SET ? WHERE userId = ?",
        [updatedData, userId],
        (err, result) => {
          if (err) {
            console.error(err);
            return res.status(500).json({ error: "Failed to update record" });
          }

          if (result.affectedRows === 0) {
            // Check if record was updated successfully
            return res.status(404).json({ message: "Record not found" });
          }

          res.json({ message: "Record updated successfully" });
        }
      );
    },
    login: (req, res) => {
      const { Emailid, Password } = req.body;

      try {
        // Check if the email exists in the database
        db.query(
          "SELECT * FROM users WHERE Emailid = ?",
          Emailid,
          async (error, results) => {
            console.log(error);
            console.log(results);
            if (error) {
              console.error("Error fetching user:", error);
              return res.status(500).json({ error: "Internal server error" });
            }

            if (results.length === 0) {
              // User with the provided email doesn't exist

              return res.status(401).json({ error: "Invalid credentials" });
            }

            const user = results[0];

            // Compare the provided password with the hashed password from the database
            if (req.body.Password === user.Password) {
              // Passwords match, generate JWT token
              const token = jwt.sign(
                { UserId: user.UserId, Emailid: user.Emailid },
                "nb13",
                { expiresIn: "1h" }
              );
              res.status(200).json({ token });
            } else {
              // Passwords don't match
              res.status(401).json({ error: "Invalid credentials" });
            }
          }
        );
      } catch (error) {
        console.error("Error during login:", error);
        res.status(500).json({ error: "Internal server error" });
      }
    },
    deleteuser: (req, res) => {
      const Firstname = req.query.Firstname;
      const sql = "DELETE FROM users WHERE Firstname = ?";
      db.query(sql, Firstname, (err, result) => {
        if (err) {
          res.status(400).json({ error: err.message });
        } else if (result.affectedRows === 0) {
          res.status(404).json({ message: "User not found" });
        } else {
          res.json({ message: "User deleted successfully" });
        }
      });
    },
    postrole: (req, res) => {
      const { RoleId, Rolename } = req.body;
      const newUser = {
        RoleId,
        Rolename,
      };

      const sql = "INSERT INTO roles SET ?";

      db.query(sql, newUser, (err, result) => {
        if (err) {
          console.log(err);
          res.status(500).send("Error saving data");
          return;
        }
        console.log("role registered:", result);
        res.status(200).send("role registered successfully");
      });
    },
    getrole: (req, res) => {
      const page = parseInt(req.query.page) || 1;
      const perPage = parseInt(req.query.perPage) || 10;

      const offset = (page - 1) * perPage;

      const sql = `SELECT * FROM roles LIMIT ${perPage} OFFSET ${offset}`;
      const countQuery = "SELECT COUNT(*) AS total FROM block";

      db.query(countQuery, (countErr, countResult) => {
        if (countErr) {
          console.error("Error counting block:", countErr);
          res.status(500).json({ error: "Error counting block" });
          return;
        }

        const total = countResult[0].total;

        db.query(sql, (err, result) => {
          if (err) {
            console.error("Error fetching block:", err);
            res.status(500).json({ error: "Error fetching block" });
            return;
          }
          const totalPages = Math.ceil(total / perPage);
          res.json({
            page,
            perPage,
            total,
            totalPages,
            block: result,
          });
        });
      });
    },
    signupticket: (req, res) => {
      const { Id, UserId, type, Subject, status, attachment, IsActive } =
        req.body;
      const newUser = {
        Id,
        UserId,
        type,
        Subject,
        status,
        attachment,
        createdAt: new Date(),
        UpdatedAt: new Date(),
        IsActive,
      };

      const sql = "INSERT INTO ticket SET ?";

      db.query(sql, newUser, (err, result) => {
        if (err) {
          console.log(err);
          res.status(500).send("Error saving data");
          return;
        }
        console.log("Ticket registered:", result);
        res.status(200).send("Ticket registered successfully");
      });
    },
    getticket: (req, res) => {
      const page = parseInt(req.query.page) || 1; // Current page, default is 1
      const perPage = parseInt(req.query.perPage) || 10; // Number of items per page, default is 10

      // Calculate the offset based on the current page and items per page
      const offset = (page - 1) * perPage;

      // Query to fetch users with pagination
      const sql = `SELECT * FROM ticket LIMIT ${perPage} OFFSET ${offset}`;

      // Query to count total users
      const countQuery = "SELECT COUNT(*) AS total FROM ticket";

      db.query(countQuery, (countErr, countResult) => {
        if (countErr) {
          console.error("Error counting users:", countErr);
          res.status(500).json({ error: "Error counting users" });
          return;
        }

        const total = countResult[0].total;

        // Execute main query to fetch users
        db.query(sql, (err, result) => {
          if (err) {
            console.error("Error fetching users:", err);
            res.status(500).json({ error: "Error fetching users" });
            return;
          }

          // Calculate total pages
          const totalPages = Math.ceil(total / perPage);
          console.log(totalPages);

          // Send retrieved records along with pagination metadata as response
          res.json({
            page,
            perPage,
            total,
            totalPages,
            tickets: result,
          });
        });
      });

      // db.query("SELECT * FROM ticket", (err, result) => {
      //   if (err) throw err;

      //   // Send retrieved records as response
      //   res.json(result);
      // });
    },
    updateticket: (req, res) => {
      const Id = req.body.Id;
      const { status } = req.body; // Assuming the request body contains the updated data

      // Query database to update record
      db.query(
        "UPDATE ticket SET ? WHERE Id = ?",
        [{ status, updatedAt: new Date() }, Id],
        (err, result) => {
          if (err) {
            console.error(err);
            return res.status(500).json({ error: "Failed to update record" });
          }

          if (result.affectedRows === 0) {
            // Check if record was updated successfully
            return res.status(404).json({ message: "Record not found" });
          }

          res.json({ message: "Record updated successfully" });
        }
      );
    },
    signupticketreplies: (req, res) => {
      const { ticketId, IsAdminReply, flag, replyText, attachment, IsActive } =
        req.body;
      const newUser = {
        ticketId,
        createdAt: new Date(),
        IsAdminReply,
        flag,
        replyText,
        attachment,
        IsActive,
      };

      const sql = "INSERT INTO ticket_replies SET ?";

      db.query(sql, newUser, (err, result) => {
        if (err) {
          console.log(err);
          res.status(500).send("Error saving data");
          return;
        }
        console.log(" Reply for Ticket is registered:", result);
        res.status(200).send("Ticket Reply registered successfully");
      });
    },
    getticketreplies: (req, res) => {
      // Query database to retrieve records
      db.query("SELECT * FROM ticket_replies", (err, result) => {
        if (err) throw err;

        // Send retrieved records as response
        res.json(result);
      });
    },
    updateticketreplies: (req, res) => {
      const Id = req.body.Id;
      const IsAdminReply = req.body; // Assuming the request body contains the updated data

      // Query database to update record
      db.query(
        "UPDATE ticket_replies SET ? WHERE Id = ?",
        [IsAdminReply, Id],
        (err, result) => {
          if (err) {
            console.error(err);
            return res.status(500).json({ error: "Failed to update record" });
          }

          if (result.affectedRows === 0) {
            // Check if record was updated successfully
            return res.status(404).json({ message: "Record not found" });
          }

          res.json({ message: "Record updated successfully" });
        }
      );
    },
    getticketwithreplies: (req, res) => {
      const { ticketId } = req.query;
      console.log(ticketId);
      if (!ticketId) {
        res.status(400).json({ error: "Missing ticketId parameter" });
        return;
      }
      const sql = `
      SELECT ticket.*,ticket_replies.*
      from ticket 
      LEFT JOIN ticket_replies  ON ticket.Id=ticket_replies.ticketId
      WHERE ticket.Id = ?
      `;

      db.query(sql, [ticketId], (err, results) => {
        if (err) {
          console.error("Error fetching ticket and replies: ", err);
          res.status(500).json({ error: "Internal Server Error" });
          return;
        }

        if (results.length === 0) {
          res.status(404).json({ message: "Ticket not found" });
          return;
        }

        const ticket = {
          Id: results[0].Id,
          UserId: results[0].UserId,
          Subject: results[0].Subject,
          Status: results[0].Status,
          Type: results[0].Type,
          Attachment: results[0].Attachment,
          CreatedAt: results[0].createdAt,
          UpdatedAt: results[0].UpdatedAt,
        };

        const replies = results.map((reply) => ({
          Id: reply.Id,
          TicketId: reply.ticketId,
          CreatedAt: reply.CreatedAt,
          IsAdminReply: reply.IsAdminReply,
          flag: reply.flag,
          ReplyText: reply.ReplyText,
          Attachment: reply.Attachment,
          IsActive: reply.IsActive,
        }));

        // Construct API response
        res.status(200).json({ ticket, replies });
      });
    },
    getticketbyid: (req, res) => {
      const { Id } = req.query;
      // Construct SQL query to fetch ticket by ID
      console.log(Id);
      const sql = `SELECT * FROM ticket WHERE Id = ?`;

      db.query(sql, [Id], (err, results) => {
        if (err) {
          console.error("Error fetching ticket by ID:", err);
          res.status(500).json({ error: "Internal Server Error" });
          return;
        }

        if (results.length === 0) {
          res.status(404).json({ message: "Ticket not found" });
          return;
        }

        // Ticket found, send it as response
        const ticket = results[0]; // Assuming ticketId is unique, so only one result
        console.log(ticket);
        res.status(200).json(ticket);
      });
    },
    signupflats: (req, res) => {
      const { Flat_No, Area, No_of_bedrooms, Status, User_Id, Block_Id } =
        req.body;
      const newUser = {
        Flat_No,
        Area,
        No_of_bedrooms,
        Status,
        User_Id,
        Block_Id,
      };

      const sql = "INSERT INTO flats SET ?";

      db.query(sql, newUser, (err, result) => {
        if (err) {
          console.log(err);
          res.status(500).send("Error saving data");
          return;
        }
        console.log("flat registered:", result);
        res.status(200).send("flat registered successfully");
      });
    },
    getflats: (req, res) => {
      const page = parseInt(req.query.page) || 1; // Current page, default is 1
      const perPage = parseInt(req.query.perPage) || 10; // Number of items per page, default is 10

      // Calculate the offset based on the current page and items per page
      const offset = (page - 1) * perPage;

      // Query to fetch users with pagination
      const sql = `SELECT * FROM flats LIMIT ${perPage} OFFSET ${offset}`;

      // Query to count total users
      const countQuery = "SELECT COUNT(*) AS total FROM flats";

      db.query(countQuery, (countErr, countResult) => {
        if (countErr) {
          console.error("Error counting flats:", countErr);
          res.status(500).json({ error: "Error counting flats" });
          return;
        }

        const total = countResult[0].total;

        // Execute main query to fetch users
        db.query(sql, (err, result) => {
          if (err) {
            console.error("Error fetching flats:", err);
            res.status(500).json({ error: "Error fetching flats" });
            return;
          }

          // Calculate total pages
          const totalPages = Math.ceil(total / perPage);
          console.log(totalPages);

          // Send retrieved records along with pagination metadata as response
          res.json({
            page,
            perPage,
            total,
            totalPages,
            flats: result,
          });
        });
      });
    },
    getflatsbyuserid: (req, res) => {
      const { User_Id } = req.query;
      const sql = `SELECT * FROM flats WHERE User_Id = ?`;

      db.query(sql, [User_Id], (err, results) => {
        if (err) {
          console.error("Error fetching flat by  User_Id:", err);
          res.status(500).json({ error: "Internal Server Error" });
          return;
        }

        if (results.length === 0) {
          res.status(404).json({ message: "User_Id not found" });
          return;
        }

        const flat = results;
        console.log(flat);
        res.status(200).json(flat);
      });
    },
    getflatswithuserbyuserid: (req, res) => {
      const { User_Id } = req.query;
      if (!User_Id) {
        res.status(400).json({ error: "Missing userId parameter" });
        return;
      }
      const sql = `
      SELECT flats.*,users.*
      from flats
      LEFT JOIN users  ON flats.User_Id=users.userId
      WHERE flats.User_Id = ?
      `;

      db.query(sql, [User_Id], (err, results) => {
        if (err) {
          console.error("Error fetching flats an users: ", err);
          res.status(500).json({ error: "Internal Server Error" });
          return;
        }

        if (results.length === 0) {
          res.status(404).json({ message: "Userid not found" });
          return;
        }

        const flats = {
          Flat_No: results[0].Flat_No,
          No_of_bedrooms: results[0].No_of_bedrooms,
          Status: results[0].Status,
          Block_Id: results[0].Block_Id,
        };

        const user = results.map((reply) => ({
          userId: reply.userId,
          Firstname: reply.Firstname,
          Lastname: reply.Lastname,
          Emailid: reply.Emailid,
          Phonenumber: reply.Phonenumber,
        }));

        // Construct API response
        res.status(200).json({ flats, user });
      });
    },
    updateflats: (req, res) => {
      const Flat_Id = req.body.Flat_Id;
      const updatedData = req.body;

      db.query(
        "UPDATE flats SET ? WHERE Flat_Id = ?",
        [updatedData, Flat_Id],
        (err, result) => {
          if (err) {
            console.error(err);
            return res.status(500).json({ error: "Failed to update record" });
          }

          if (result.affectedRows === 0) {
            return res.status(404).json({ message: "Record not found" });
          }

          res.json({ message: "Record updated successfully" });
        }
      );
    },
    signupblock: (req, res) => {
      const { Id, Block_Name } = req.body;
      const newUser = {
        Id,
        Block_Name,
      };

      const sql = "INSERT INTO block SET ?";

      db.query(sql, newUser, (err, result) => {
        if (err) {
          console.log(err);
          res.status(500).send("Error saving data");
          return;
        }
        console.log("block registered:", result);
        res.status(200).send("block registered successfully");
      });
    },
    getblock: (req, res) => {
      const page = parseInt(req.query.page) || 1;
      const perPage = parseInt(req.query.perPage) || 10;

      const offset = (page - 1) * perPage;

      const sql = `SELECT * FROM block LIMIT ${perPage} OFFSET ${offset}`;
      const countQuery = "SELECT COUNT(*) AS total FROM block";

      db.query(countQuery, (countErr, countResult) => {
        if (countErr) {
          console.error("Error counting block:", countErr);
          res.status(500).json({ error: "Error counting block" });
          return;
        }

        const total = countResult[0].total;

        db.query(sql, (err, result) => {
          if (err) {
            console.error("Error fetching block:", err);
            res.status(500).json({ error: "Error fetching block" });
            return;
          }
          const totalPages = Math.ceil(total / perPage);
          res.json({
            page,
            perPage,
            total,
            totalPages,
            block: result,
          });
        });
      });
    },
    getblockwithflatsbyblockid: (req, res) => {
      const { Id } = req.query;

      if (!Id) {
        res.status(400).json({ error: "Missing Block Id parameter" });
        return;
      }
      const sql = `
      SELECT block.*,flats.*
      from block
      LEFT JOIN flats  ON block.Id=flats.Block_Id
      WHERE block.Id= ?
      `;

      db.query(sql, [Id], (err, results) => {
        if (err) {
          res.status(500).json({ error: "Internal Server Error" });
          return;
        }

        if (results.length === 0) {
          res.status(404).json({ message: "Block id not found" });
          return;
        }

        const block = {
          Block_Name: results[0].Block_Name,
        };

        const flats = results.map((reply) => ({
          Flat_No: reply.Flat_No,
          Area: reply.Area,
          No_of_bedrooms: reply.No_of_bedrooms,
          Status: reply.Status,
          User_Id: reply.User_Id,
        }));

        // Construct API response
        res.status(200).json({ block, flats });
      });
    },
    posttransactionhistory: (req, res) => {
      const {
        Iduser,
        Paid_Amount,
        Remaining_Amount,
        Payment_Screenshot,
        Payment_Date,
        Payment_Type,
        Payment_Method,
        IsActive,
      } = req.body;
      const newUser = {
        Iduser,
        Paid_Amount,
        Remaining_Amount,
        Payment_Screenshot,
        Payment_Date,
        Payment_Type,
        Payment_Method,
        IsActive,
      };

      const sql = "INSERT INTO transaction_history SET ?";

      db.query(sql, newUser, (err, result) => {
        if (err) {
          console.log(err);
          res.status(500).send("Error saving data");
          return;
        }
        console.log("transaction registered:", result);
        res.status(200).send("transaction registered successfully");
      });
    },
    gettransactionhistory: (req, res) => {
      const page = parseInt(req.query.page) || 1;
      const perPage = parseInt(req.query.perPage) || 10;

      const offset = (page - 1) * perPage;

      const sql = `SELECT * FROM transaction_history LIMIT ${perPage} OFFSET ${offset}`;
      const countQuery = "SELECT COUNT(*) AS total FROM transaction_history";

      db.query(countQuery, (countErr, countResult) => {
        if (countErr) {
          console.error("Error counting history:", countErr);
          res.status(500).json({ error: "Error counting history" });
          return;
        }

        const total = countResult[0].total;

        db.query(sql, (err, result) => {
          if (err) {
            console.error("Error fetching history:", err);
            res.status(500).json({ error: "Error fetching history" });
            return;
          }
          const totalPages = Math.ceil(total / perPage);
          res.json({
            page,
            perPage,
            total,
            totalPages,
            transactionhistory: result,
          });
        });
      });
    },
    gettransactionhistorybyuserid: (req, res) => {
      const { Iduser } = req.query;
      const sql = `SELECT * FROM transaction_history WHERE Iduser = ?`;

      db.query(sql, [Iduser], (err, results) => {
        if (err) {
          console.error("Error fetching history with iduser:", err);
          res.status(500).json({ error: "Internal Server Error" });
          return;
        }

        if (results.length === 0) {
          res.status(404).json({ message: "Iduser not found" });
          return;
        }

        const transactionhistory = results;
        console.log(transactionhistory);
        res.status(200).json(transactionhistory);
      });
    },
    updatetransactionhistory: (req, res) => {
      const Id = req.body.Id;
      const updatedData = req.body;

      db.query(
        "UPDATE transaction_history SET ? WHERE Id = ?",
        [updatedData, Id],
        (err, result) => {
          if (err) {
            console.error(err);
            return res.status(500).json({ error: "Failed to update record" });
          }

          if (result.affectedRows === 0) {
            return res.status(404).json({ message: "Record not found" });
          }

          res.json({ message: "Record updated successfully" });
        }
      );
    },
    signupexpenses: (req, res) => {
      const { Id, Expense_Name, IsActive } = req.body;
      const newUser = {
        Id,
        Expense_Name,
        IsActive,
      };

      const sql = "INSERT INTO expense SET ?";

      db.query(sql, newUser, (err, result) => {
        if (err) {
          console.log(err);
          res.status(500).send("Error saving data");
          return;
        }
        console.log("expense with name registered:", result);
        res.status(200).send("expenses with name registered successfully");
      });
    },
    getexpenses: (req, res) => {
      const page = parseInt(req.query.page) || 1;
      const perPage = parseInt(req.query.perPage) || 10;

      const offset = (page - 1) * perPage;

      const sql = `SELECT * FROM expense LIMIT ${perPage} OFFSET ${offset}`;
      const countQuery = "SELECT COUNT(*) AS total FROM expense";

      db.query(countQuery, (countErr, countResult) => {
        if (countErr) {
          console.error("Error counting expenses:", countErr);
          res.status(500).json({ error: "Error counting expenses" });
          return;
        }

        const total = countResult[0].total;

        db.query(sql, (err, result) => {
          if (err) {
            console.error("Error fetching expenses:", err);
            res.status(500).json({ error: "Error fetching expenses" });
            return;
          }
          const totalPages = Math.ceil(total / perPage);
          res.json({
            page,
            perPage,
            total,
            totalPages,
            expenses: result,
          });
        });
      });
    },
    updateexpenses: (req, res) => {
      const Id = req.body.Id;
      const updatedData = req.body;

      db.query(
        "UPDATE expense SET ? WHERE Id = ?",
        [updatedData, Id],
        (err, result) => {
          if (err) {
            console.error(err);
            return res.status(500).json({ error: "Failed to update record" });
          }

          if (result.affectedRows === 0) {
            return res.status(404).json({ message: "Record not found" });
          }

          res.json({ message: "Record updated successfully" });
        }
      );
    },
    signupexpensesheet: (req, res) => {
      const { Expense_Id, Paid_Amount, Remaining_Amount, Month } = req.body;
      const newUser = {
        Expense_Id,
        Paid_Amount,
        Remaining_Amount,
        Month,
        Created_At: new Date(),
      };

      const sql = "INSERT INTO expensesheet_for_admin SET ?";

      db.query(sql, newUser, (err, result) => {
        if (err) {
          console.log(err);
          res.status(500).send("Error saving data");
          return;
        }
        console.log("expensesheet  registered:", result);
        res.status(200).send("expensesheet  registered successfully");
      });
    },
    getexpensesheet: (req, res) => {
      const page = parseInt(req.query.page) || 1;
      const perPage = parseInt(req.query.perPage) || 10;

      const offset = (page - 1) * perPage;

      const sql = `SELECT * FROM expensesheet_for_admin LIMIT ${perPage} OFFSET ${offset}`;
      const countQuery = "SELECT COUNT(*) AS total FROM expensesheet_for_admin";

      db.query(countQuery, (countErr, countResult) => {
        if (countErr) {
          console.error("Error counting expense sheet:", countErr);
          res.status(500).json({ error: "Error counting expense sheet" });
          return;
        }

        const total = countResult[0].total;

        db.query(sql, (err, result) => {
          if (err) {
            console.error("Error fetching expense sheet:", err);
            res.status(500).json({ error: "Error fetching expense sheet" });
            return;
          }
          const totalPages = Math.ceil(total / perPage);
          res.json({
            page,
            perPage,
            total,
            totalPages,
            expensesheet: result,
          });
        });
      });
    },
    updateexpensesheet: (req, res) => {
      const Id = req.body.Id;
      const updatedData = req.body;

      db.query(
        "UPDATE expensesheet_for_admin SET ? WHERE Id = ?",
        [updatedData, Id],
        (err, result) => {
          if (err) {
            console.error(err);
            return res.status(500).json({ error: "Failed to update record" });
          }

          if (result.affectedRows === 0) {
            return res.status(404).json({ message: "Record not found" });
          }

          res.json({ message: "Record updated successfully" });
        }
      );
    },
    getexpensewithexpensesheetbyexpenseid: (req, res) => {
      const { Id } = req.query;

      if (!Id) {
        res.status(400).json({ error: "Missing expense Id parameter" });
        return;
      }
      const sql = `
      SELECT expense.*,expensesheet_for_admin.*
      from expense
      LEFT JOIN expensesheet_for_admin  ON expense.Id=expensesheet_for_admin.Expense_Id
      WHERE expense.Id= ?
      `;

      db.query(sql, [Id], (err, results) => {
        if (err) {
          res.status(500).json({ error: "Internal Server Error" });
          return;
        }

        if (results.length === 0) {
          res.status(404).json({ message: "expense id not found" });
          return;
        }

        const expense = {
          Expense_Name: results[0].Expense_Name,
        };

        const sheet = results.map((reply) => ({
          Id: reply.Id,
          Paid_Amount: reply.Paid_Amount,
          Remaining_Amount: reply.Remaining_Amount,
          Month: reply.Month,
          Created_At: reply.Created_At,
        }));

        // Construct API response
        res.status(200).json({ expense, sheet });
      });
    },
    deleteexpensesheet: (req, res) => {
      const Id = req.query.Id;
      const sql = "DELETE FROM expensesheet_for_admin WHERE Id = ?";
      db.query(sql, Id, (err, result) => {
        if (err) {
          res.status(400).json({ error: err.message });
        } else if (result.affectedRows === 0) {
          res.status(404).json({ message: "record not found" });
        } else {
          res.json({ message: "record deleted successfully" });
        }
      });
    },
    signupmaintenancecharges: (req, res) => {
      const { Month, Description, Amount } = req.body;
      const newUser = {
        Month,
        Description,
        Amount,
        Created_At: new Date(),
      };

      const sql = "INSERT INTO  maintenance_charges SET ?";

      db.query(sql, newUser, (err, result) => {
        if (err) {
          console.log(err);
          res.status(500).send("Error saving data");
          return;
        }
        console.log("maintenancecharges  registered:", result);
        res.status(200).send("maintenancecharges registered successfully");
      });
    },
    getmaintenancecharges: (req, res) => {
      const page = parseInt(req.query.page) || 1;
      const perPage = parseInt(req.query.perPage) || 10;

      const offset = (page - 1) * perPage;

      const sql = `SELECT * FROM maintenance_charges LIMIT ${perPage} OFFSET ${offset}`;
      const countQuery = "SELECT COUNT(*) AS total FROM maintenance_charges";

      db.query(countQuery, (countErr, countResult) => {
        if (countErr) {
          console.error("Error counting charges:", countErr);
          res.status(500).json({ error: "Error counting charges" });
          return;
        }

        const total = countResult[0].total;

        db.query(sql, (err, result) => {
          if (err) {
            console.error("Error fetching charges:", err);
            res.status(500).json({ error: "Error fetching charges" });
            return;
          }
          const totalPages = Math.ceil(total / perPage);
          res.json({
            page,
            perPage,
            total,
            totalPages,
            maintenancecharges: result,
          });
        });
      });
    },
    getchargespermonth: (req, res) => {
      const { Month } = req.query;
      const sql = `SELECT * FROM maintenance_charges WHERE Month = ?`;

      db.query(sql, [Month], (err, results) => {
        if (err) {
          console.error("Error fetching charges with month:", err);
          res.status(500).json({ error: "Internal Server Error" });
          return;
        }

        if (results.length === 0) {
          res.status(404).json({ message: "month not found" });
          return;
        }

        const charges_per_month = results;
        console.log(charges_per_month);
        res.status(200).json(charges_per_month);
      });
    },
    updatemaintenancecharges: (req, res) => {
      const Id = req.body.Id;
      const updatedData = req.body;

      db.query(
        "UPDATE maintenance_charges SET ? WHERE Id = ?",
        [updatedData, Id],
        (err, result) => {
          if (err) {
            console.error(err);
            return res.status(500).json({ error: "Failed to update record" });
          }

          if (result.affectedRows === 0) {
            return res.status(404).json({ message: "Record not found" });
          }

          res.json({ message: "Record updated successfully" });
        }
      );
    },
  };
})();
