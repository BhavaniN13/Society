let usercontroller = require("../controllers/usercontrollers");

module.exports = function (app) {
  app.post("/signup", (req, res) => {
    usercontroller.signup(req, res);
  });
  app.get("/getuser", (req, res) => {
    usercontroller.getuser(req, res);
  });
  app.put("/updateuser", (req, res) => {
    usercontroller.updateuser(req, res);
  });
  app.post("/login", (req, res) => {
    usercontroller.login(req, res);
  });
  app.delete("/deleteuser", (req, res) => {
    usercontroller.deleteuser(req, res);
  });
  app.post("/role", (req, res) => {
    usercontroller.postrole(req, res);
  });
  app.get("/getrole", (req, res) => {
    usercontroller.getrole(req, res);
  });
  app.post("/signupticket", (req, res) => {
    usercontroller.signupticket(req, res);
  });
  app.get("/getticket", (req, res) => {
    usercontroller.getticket(req, res);
  });
  app.put("/updateticket", (req, res) => {
    usercontroller.updateticket(req, res);
  });
  app.post("/signupticketreplies", (req, res) => {
    usercontroller.signupticketreplies(req, res);
  });
  app.get("/getticketreplies", (req, res) => {
    usercontroller.getticketreplies(req, res);
  });
  app.put("/updateticketreplies", (req, res) => {
    usercontroller.updateticketreplies(req, res);
  });
  app.get("/getticketwithreplies", (req, res) => {
    usercontroller.getticketwithreplies(req, res);
  });
  app.get("/getticketbyid", (req, res) => {
    usercontroller.getticketbyid(req, res);
  });
  app.post("/signupflats", (req, res) => {
    usercontroller.signupflats(req, res);
  });
  app.get("/getflats", (req, res) => {
    usercontroller.getflats(req, res);
  });
  app.get("/getflatsbyuserid", (req, res) => {
    usercontroller.getflatsbyuserid(req, res);
  });
  app.get("/getflatswithuserbyuserid", (req, res) => {
    usercontroller.getflatswithuserbyuserid(req, res);
  });
  app.put("/updateflats", (req, res) => {
    usercontroller.updateflats(req, res);
  });
  app.post("/signupblock", (req, res) => {
    usercontroller.signupblock(req, res);
  });
  app.get("/getblock", (req, res) => {
    usercontroller.getblock(req, res);
  });
  app.get("/getblockwithflatsbyblockid", (req, res) => {
    usercontroller.getblockwithflatsbyblockid(req, res);
  });
  app.post("/transactionhistory", (req, res) => {
    usercontroller.posttransactionhistory(req, res);
  });
  app.get("/gettransactionhistory", (req, res) => {
    usercontroller.gettransactionhistory(req, res);
  });
  app.get("/gettransactionhistorybyuserid", (req, res) => {
    usercontroller.gettransactionhistorybyuserid(req, res);
  });
  app.put("/updatetransactionhistory", (req, res) => {
    usercontroller.updatetransactionhistory(req, res);
  });
  app.post("/signupexpenses", (req, res) => {
    usercontroller.signupexpenses(req, res);
  });
  app.get("/getexpenses", (req, res) => {
    usercontroller.getexpenses(req, res);
  });
  app.put("/updateexpenses", (req, res) => {
    usercontroller.updateexpenses(req, res);
  });
  app.post("/signupexpensesheet", (req, res) => {
    usercontroller.signupexpensesheet(req, res);
  });
  app.get("/getexpensesheet", (req, res) => {
    usercontroller.getexpensesheet(req, res);
  });
  app.put("/updateexpensesheet", (req, res) => {
    usercontroller.updateexpensesheet(req, res);
  });
  app.get("/getexpensewithexpensesheetbyexpenseid", (req, res) => {
    usercontroller.getexpensewithexpensesheetbyexpenseid(req, res);
  });
  app.post("/deleteexpensesheet", (req, res) => {
    usercontroller.deleteexpensesheet(req, res);
  });
  app.post("/signupmaintenancecharges", (req, res) => {
    usercontroller.signupmaintenancecharges(req, res);
  });
  app.get("/getmaintenancecharges", (req, res) => {
    usercontroller.getmaintenancecharges(req, res);
  });
  app.put("/updatemaintenancecharges", (req, res) => {
    usercontroller.updatemaintenancecharges(req, res);
  });
  app.get("/getchargespermonth", (req, res) => {
    usercontroller.getchargespermonth(req, res);
  });
};
